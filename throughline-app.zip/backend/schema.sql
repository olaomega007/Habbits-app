
-- Throughline App - Database Schema v1.0
-- Cross-Domain Habit Insight App

-- Users (managed by Supabase Auth, but we keep a profiles table)
CREATE TABLE profiles (
    id UUID PRIMARY KEY REFERENCES auth.users(id) ON DELETE CASCADE,
    email TEXT NOT NULL,
    full_name TEXT,
    subscription_status TEXT DEFAULT 'trial', -- trial, active, cancelled
    trial_ends_at TIMESTAMP WITH TIME ZONE DEFAULT (NOW() + INTERVAL '14 days'),
    created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
    updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- Logs table - the heart of everything. Generic design scales to new domains.
CREATE TABLE logs (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    user_id UUID NOT NULL REFERENCES profiles(id) ON DELETE CASCADE,
    log_date DATE NOT NULL,
    domain TEXT NOT NULL CHECK (domain IN ('finance', 'mood_sleep', 'relationships')),
    metric_type TEXT NOT NULL CHECK (metric_type IN (
        'spend_total', 'income', 'sleep_hours', 'mood_rating', 
        'social_satisfaction', 'contact_frequency'
    )),
    value NUMERIC NOT NULL,
    note TEXT,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
    updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
    UNIQUE(user_id, log_date, metric_type)
);

-- Insights table - generated weekly by the correlation engine
CREATE TABLE insights (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    user_id UUID NOT NULL REFERENCES profiles(id) ON DELETE CASCADE,
    insight_text TEXT NOT NULL,
    confidence_level TEXT NOT NULL CHECK (confidence_level IN ('low', 'medium', 'high')),
    domains_involved TEXT[] NOT NULL,
    metric_types_involved TEXT[] NOT NULL,
    correlation_value NUMERIC,
    is_read BOOLEAN DEFAULT FALSE,
    generated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- Indexes for performance
CREATE INDEX idx_logs_user_date ON logs(user_id, log_date DESC);
CREATE INDEX idx_logs_user_domain ON logs(user_id, domain);
CREATE INDEX idx_logs_user_metric ON logs(user_id, metric_type);
CREATE INDEX idx_insights_user_unread ON insights(user_id, is_read) WHERE is_read = FALSE;

-- Row Level Security policies
ALTER TABLE logs ENABLE ROW LEVEL SECURITY;
ALTER TABLE insights ENABLE ROW LEVEL SECURITY;
ALTER TABLE profiles ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Users can only see their own logs" ON logs
    FOR ALL USING (auth.uid() = user_id);

CREATE POLICY "Users can only see their own insights" ON insights
    FOR ALL USING (auth.uid() = user_id);

CREATE POLICY "Users can only see their own profile" ON profiles
    FOR ALL USING (auth.uid() = id);

-- Function to auto-update updated_at
CREATE OR REPLACE FUNCTION update_updated_at_column()
RETURNS TRIGGER AS $$
BEGIN
    NEW.updated_at = NOW();
    RETURN NEW;
END;
$$ language 'plpgsql';

CREATE TRIGGER update_profiles_updated_at BEFORE UPDATE ON profiles
    FOR EACH ROW EXECUTE FUNCTION update_updated_at_column();

CREATE TRIGGER update_logs_updated_at BEFORE UPDATE ON logs
    FOR EACH ROW EXECUTE FUNCTION update_updated_at_column();
