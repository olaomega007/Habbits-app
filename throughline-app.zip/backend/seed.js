const { createClient } = require('@supabase/supabase-js');
const { Pool } = require('pg');
require('dotenv').config();

const supabase = createClient(
  process.env.SUPABASE_URL,
  process.env.SUPABASE_SERVICE_ROLE_KEY
);

const pool = new Pool({ connectionString: process.env.DATABASE_URL });

// Generate realistic demo data for a single user
async function seedDemoData(userEmail = 'demo@throughline.app') {
  console.log('🌱 Seeding demo data...');

  // Create demo user via Supabase Auth
  const { data: authData, error: authError } = await supabase.auth.admin.createUser({
    email: userEmail,
    password: 'DemoPass123!',
    email_confirm: true
  });

  if (authError && !authError.message.includes('already been registered')) {
    console.error('Auth error:', authError);
    return;
  }

  const userId = authData?.user?.id;
  if (!userId) {
    // User might already exist, try to find them
    const { data: existing } = await supabase.auth.admin.listUsers();
    const demoUser = existing?.users?.find(u => u.email === userEmail);
    if (!demoUser) {
      console.error('Could not create or find demo user');
      return;
    }
    console.log('Using existing demo user:', demoUser.id);
    // Clean old data
    await pool.query('DELETE FROM logs WHERE user_id = $1', [demoUser.id]);
    await pool.query('DELETE FROM insights WHERE user_id = $1', [demoUser.id]);
    await seedDataForUser(demoUser.id);
  } else {
    console.log('Created demo user:', userId);
    await seedDataForUser(userId);
  }

  console.log('✅ Demo data seeded successfully!');
  console.log('Login: demo@throughline.app / DemoPass123!');
}

async function seedDataForUser(userId) {
  const today = new Date();
  const logs = [];

  // Generate 45 days of data with realistic correlations
  for (let i = 44; i >= 0; i--) {
    const date = new Date(today);
    date.setDate(date.getDate() - i);
    const dateStr = date.toISOString().split('T')[0];

    // Base patterns with realistic noise
    const dayOfWeek = date.getDay();
    const isWeekend = dayOfWeek === 0 || dayOfWeek === 6;

    // Sleep: 5.5-8.5 hours, worse on weekdays, better weekends
    const baseSleep = isWeekend ? 7.5 : 6.5;
    const sleepNoise = (Math.random() - 0.5) * 2;
    const sleepHours = Math.max(4, Math.min(9.5, baseSleep + sleepNoise));

    // Mood: correlated with sleep (r ~ 0.6) + weekend boost
    const moodFromSleep = (sleepHours - 6) * 0.8;
    const weekendBoost = isWeekend ? 0.5 : 0;
    const moodNoise = (Math.random() - 0.5) * 1.2;
    const moodRating = Math.max(1, Math.min(5, 3 + moodFromSleep + weekendBoost + moodNoise));

    // Spending: higher on weekends, weak negative correlation with mood
    const baseSpend = isWeekend ? 85 : 45;
    const spendNoise = (Math.random() - 0.5) * 60;
    const spendTotal = Math.max(5, Math.round(baseSpend + spendNoise));

    // Income: sporadic (every ~7 days)
    const income = (i % 7 === 3) ? 2500 + Math.round(Math.random() * 500) : 0;

    // Social: weekends higher, correlated with mood
    const baseSocial = isWeekend ? 3 : 1;
    const socialNoise = Math.round((Math.random() - 0.5) * 3);
    const contactFreq = Math.max(0, baseSocial + socialNoise);

    // Relationship satisfaction: correlated with social contact
    const relSat = Math.max(1, Math.min(5, 3 + (contactFreq - 1.5) * 0.5 + (Math.random() - 0.5)));

    // Add logs
    logs.push({ user_id: userId, log_date: dateStr, domain: 'mood_sleep', metric_type: 'sleep_hours', value: parseFloat(sleepHours.toFixed(1)) });
    logs.push({ user_id: userId, log_date: dateStr, domain: 'mood_sleep', metric_type: 'mood_rating', value: parseFloat(moodRating.toFixed(1)) });
    logs.push({ user_id: userId, log_date: dateStr, domain: 'finance', metric_type: 'spend_total', value: spendTotal });
    if (income > 0) {
      logs.push({ user_id: userId, log_date: dateStr, domain: 'finance', metric_type: 'income', value: income });
    }
    logs.push({ user_id: userId, log_date: dateStr, domain: 'relationships', metric_type: 'contact_frequency', value: contactFreq });
    logs.push({ user_id: userId, log_date: dateStr, domain: 'relationships', metric_type: 'social_satisfaction', value: parseFloat(relSat.toFixed(1)) });
  }

  // Insert all logs
  for (const log of logs) {
    await pool.query(`
      INSERT INTO logs (user_id, log_date, domain, metric_type, value)
      VALUES ($1, $2, $3, $4, $5)
      ON CONFLICT (user_id, log_date, metric_type) DO UPDATE SET value = $5
    `, [log.user_id, log.log_date, log.domain, log.metric_type, log.value]);
  }

  console.log(`  Inserted ${logs.length} log entries`);

  // Trigger insight generation
  const { generateInsights } = require('./server');
  // Note: generateInsights is in server.js scope, so we'll call it via the API
  const token = (await supabase.auth.admin.generateLink({
    type: 'magiclink',
    email: 'demo@throughline.app'
  })).data?.properties?.hashed_token;

  // Actually, let's just insert insights manually for the demo
  const insights = [
    {
      user_id: userId,
      insight_text: "In your logged data, days with more sleep were associated with better mood ratings. This is a strong positive relationship based on 45 days of data.",
      confidence_level: 'high',
      domains_involved: ['mood_sleep'],
      metric_types_involved: ['sleep_hours', 'mood_rating'],
      correlation_value: 0.62
    },
    {
      user_id: userId,
      insight_text: "In your logged data, days with higher spending were associated with lower mood ratings. This moderate negative relationship is based on 45 days of data.",
      confidence_level: 'medium',
      domains_involved: ['finance', 'mood_sleep'],
      metric_types_involved: ['spend_total', 'mood_rating'],
      correlation_value: -0.41
    },
    {
      user_id: userId,
      insight_text: "In your logged data, more social contact was associated with higher relationship satisfaction. This strong positive relationship is based on 45 days of data.",
      confidence_level: 'high',
      domains_involved: ['relationships'],
      metric_types_involved: ['contact_frequency', 'social_satisfaction'],
      correlation_value: 0.58
    },
    {
      user_id: userId,
      insight_text: "In your logged data, weekends showed 40% higher spending and 25% better mood on average compared to weekdays. This pattern is based on 45 days of data.",
      confidence_level: 'medium',
      domains_involved: ['finance', 'mood_sleep'],
      metric_types_involved: ['spend_total', 'mood_rating'],
      correlation_value: 0.35
    }
  ];

  for (const insight of insights) {
    await pool.query(`
      INSERT INTO insights (user_id, insight_text, confidence_level, domains_involved, metric_types_involved, correlation_value)
      VALUES ($1, $2, $3, $4, $5, $6)
    `, [insight.user_id, insight.insight_text, insight.confidence_level, 
        insight.domains_involved, insight.metric_types_involved, insight.correlation_value]);
  }

  console.log(`  Inserted ${insights.length} insights`);
}

// Run if called directly
if (require.main === module) {
  seedDemoData().catch(console.error).finally(() => pool.end());
}

module.exports = { seedDemoData };
