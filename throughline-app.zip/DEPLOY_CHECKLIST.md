# Throughline — 2-Week Demo Deployment Checklist

## Day 1-2: Foundation ✅
- [x] Database schema designed
- [x] Backend API scaffolded
- [x] Auth middleware implemented
- [x] Correlation engine v1 built
- [x] Frontend screens created
- [x] Demo data seeder ready

## Day 3-4: Integration
- [ ] Run schema.sql on Supabase
- [ ] Deploy backend to Render/Railway
- [ ] Deploy frontend to Vercel
- [ ] Configure Stripe webhook
- [ ] Test auth flow end-to-end
- [ ] Run demo seeder on production DB

## Day 5-7: Polish
- [ ] Smooth page transitions
- [ ] Loading skeletons
- [ ] Empty state illustrations
- [ ] Error handling (network, auth)
- [ ] Mobile responsiveness audit
- [ ] PWA install prompt

## Day 8-10: Demo Flow
- [ ] Investor demo script
- [ ] Screen recording of core loop
- [ ] "Aha moment" walkthrough
- [ ] Live demo environment (demo@throughline.app)
- [ ] Backup plan (screenshots if live fails)

## Day 11-14: Pitch Prep
- [ ] Technical Q&A prep
- [ ] Architecture diagram
- [ ] Roadmap slide (Month 2-6)
- [ ] Monetization model detail
- [ ] Competitive differentiation talking points

## Pre-Demo Checklist
- [ ] Demo account has 45 days of realistic data
- [ ] All screens load in < 2 seconds
- [ ] No console errors
- [ ] Subscription flow works in test mode
- [ ] Mobile view tested on actual device
