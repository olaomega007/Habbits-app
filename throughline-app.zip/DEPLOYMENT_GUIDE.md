# Throughline — Deployment Guide

## Overview

| Service | Platform | Cost (MVP) |
|---------|----------|------------|
| Database | Supabase (already set up) | Free tier |
| Backend API | Render or Railway | Free tier |
| Frontend (PWA) | Vercel or Netlify | Free tier |
| Payments | Stripe (test mode) | Free |
| **Total monthly cost** | | **$0** |

---

## Step 1: Deploy Database Schema to Supabase

1. Go to [Supabase Dashboard](https://supabase.com/dashboard)
2. Select your project: `flmoqlkoqgvrxuzcnuqg`
3. Left sidebar → **SQL Editor** → **New query**
4. Copy entire contents of `backend/schema.sql`
5. Click **Run**
6. Verify tables created: `profiles`, `logs`, `insights`

**Time: 2 minutes**

---

## Step 2: Deploy Backend (Render — Recommended)

### Option A: Render (Easiest)

1. Go to [render.com](https://render.com) → Sign up with GitHub
2. Click **New** → **Blueprint** (or **Web Service** if no repo yet)
3. Connect your GitHub repo (or create one, push code)
4. Render auto-detects `render.yaml` and configures everything
5. Add environment variables in Render Dashboard:
   - `SUPABASE_URL` = `https://flmoqlkoqgvrxuzcnuqg.supabase.co`
   - `SUPABASE_ANON_KEY` = `sb_publishable_Os6B4OWTcoF_mhq9nl_Chw_jmlXwsBC`
   - `SUPABASE_SERVICE_ROLE_KEY` = `sb_secret_rTNJql1Feo0hsqGtNdnqgw_-WlMJNiQ`
   - `DATABASE_URL` = Get from Supabase → Project Settings → Database → Connection string (use **Session pooler** for serverless)
   - `JWT_SECRET` = Get from Supabase → Project Settings → API → JWT Settings → JWT Secret
   - `STRIPE_SECRET_KEY` = `sk_test_51TvpnFR1LulYB9FPsBFaSEtOKiPq2WNWC3sXHKRxHEXJ23FnSO8nVSrEbBcQYOEYENQeFqFVyNppQM1L32ZBAFhK00PsHImZMD`
   - `STRIPE_PRICE_ID` = `price_1TvqEER1LulYB9FPHokKaEBh`
   - `STRIPE_WEBHOOK_SECRET` = (leave blank for now, get in Step 4)
6. Click **Deploy**
7. Wait 2-3 minutes. Your API will be at `https://throughline-api.onrender.com`

### Option B: Railway

1. Go to [railway.app](https://railway.app) → Sign up
2. **New Project** → **Deploy from GitHub repo**
3. Select your repo
4. Railway auto-detects `railway.toml` + `nixpacks.toml`
5. Add same env vars as above in Railway Dashboard → Variables
6. Deploy

**Time: 10 minutes**

---

## Step 3: Deploy Frontend (Vercel — Recommended)

### Option A: Vercel (Best for React)

1. Go to [vercel.com](https://vercel.com) → Sign up with GitHub
2. **Add New Project** → Import your GitHub repo
3. Vercel auto-detects `vercel.json` and `vite.config.js`
4. Framework preset: **Vite**
5. Build command: `npm run build`
6. Output directory: `dist`
7. Environment variables (already in `vercel.json`, but verify):
   - `VITE_SUPABASE_URL` = `https://flmoqlkoqgvrxuzcnuqg.supabase.co`
   - `VITE_SUPABASE_ANON_KEY` = `sb_publishable_Os6B4OWTcoF_mhq9nl_Chw_jmlXwsBC`
   - `VITE_STRIPE_PUBLISHABLE_KEY` = `pk_test_51TvpnFR1LulYB9FPGnaWDbOYsCyxGkpUuoxWUUGoFU0U03g4XwPtx7uB6Y5dZv9wVeNjfRMliQ1pPgsbP5JJySkN00oqfUmp1o`
8. Click **Deploy**
9. Your app will be at `https://throughline-app.vercel.app`

### Option B: Netlify

1. Go to [netlify.com](https://netlify.com) → Sign up
2. **Add new site** → **Import from Git**
3. Select repo
4. Netlify auto-detects `netlify.toml`
5. Deploy

**Time: 5 minutes**

---

## Step 4: Configure Stripe Webhook

### For Production:

1. Go to [Stripe Dashboard](https://dashboard.stripe.com) → **Developers** → **Webhooks**
2. Click **Add endpoint**
3. Endpoint URL: `https://your-render-url.com/api/webhooks/stripe`
   (Replace with your actual Render URL from Step 2)
4. Select events: `checkout.session.completed`
5. Click **Add endpoint**
6. Copy the **Signing secret** (starts with `whsec_...`)
7. Go back to Render Dashboard → your service → Environment
8. Add: `STRIPE_WEBHOOK_SECRET` = the secret you just copied
9. Redeploy (or just restart service)

### For Local Testing:

```bash
# Install Stripe CLI
brew install stripe/stripe-cli/stripe  # macOS
# or download from stripe.com/docs/stripe-cli

# Login
stripe login

# Forward webhooks to local backend
stripe listen --forward-to http://localhost:3001/api/webhooks/stripe

# Copy the webhook signing secret to your .env
```

**Time: 5 minutes**

---

## Step 5: Update Frontend API URL

After backend is deployed, update the frontend to point to production API:

1. In `frontend/src/App.jsx` or create `frontend/src/config.js`:

```javascript
export const API_URL = process.env.NODE_ENV === 'production' 
  ? 'https://your-render-url.com'  // <-- Replace with real URL
  : 'http://localhost:3001'
```

2. Update all `fetch('/api/...')` calls to `fetch(`${API_URL}/api/...`)`
3. Or better: set up a proxy in `vite.config.js` for dev, and use absolute URLs in production

**Alternative (easier):** Set up CORS properly and use the full URL everywhere.

**Time: 5 minutes**

---

## Step 6: Seed Demo Data (For Investor Demo)

```bash
# SSH into your Render service or run locally against production DB
# Set DATABASE_URL to production Supabase connection string
export DATABASE_URL="postgresql://postgres:[PASSWORD]@db.flmoqlkoqgvrxuzcnuqg.supabase.co:5432/postgres"
export SUPABASE_URL="https://flmoqlkoqgvrxuzcnuqg.supabase.co"
export SUPABASE_SERVICE_ROLE_KEY="sb_secret_rTNJql1Feo0hsqGtNdnqgw_-WlMJNiQ"

node backend/seed.js
```

This creates:
- Demo user: `demo@throughline.app` / `DemoPass123!`
- 45 days of realistic correlated data
- 4 pre-generated insights

**Time: 2 minutes**

---

## Step 7: Test Everything

### Auth Flow
1. Open frontend URL
2. Sign up with new email
3. Verify email (check spam)
4. Should land on Dashboard

### Logging Flow
1. Tap "Log today"
2. Enter mood (3), sleep (7), spending ($45)
3. Save → should redirect to Dashboard with updated stats

### Insights Flow
1. After 14+ days of data, insights auto-generate
2. Or use demo account for instant insights

### Subscription Flow
1. Go to Settings
2. Click "Upgrade to Pro — $4.99/mo"
3. Use Stripe test card: `4242 4242 4242 4242`, any future date, any CVC
4. Should redirect to success, subscription status updates

**Time: 10 minutes**

---

## Troubleshooting

### CORS Errors
- Backend must allow frontend origin:
```javascript
app.use(cors({
  origin: ['https://your-vercel-url.vercel.app', 'http://localhost:3000'],
  credentials: true
}))
```

### Database Connection Issues
- Use Supabase **Session pooler** connection string, not direct
- Format: `postgresql://postgres.[project]:[password]@aws-0-[region].pooler.supabase.com:6543/postgres`

### Stripe Webhook Not Firing
- Verify endpoint URL is correct and publicly accessible
- Check Stripe Dashboard → Webhooks → recent events
- Check Render logs for webhook handler errors

### PWA Not Installing
- Ensure `manifest.json` is served correctly
- Check Chrome DevTools → Application → Manifest
- Needs HTTPS (Vercel/Netlify provide this)

---

## Post-Deployment Checklist

- [ ] Backend health check: `GET /api/health` returns 200
- [ ] Frontend loads without console errors
- [ ] Auth: sign up → verify → login works
- [ ] Logging: create entry → appears in dashboard
- [ ] Insights: demo account shows 4 insights
- [ ] Charts: trends page renders line charts
- [ ] Subscription: Stripe checkout works with test card
- [ ] Webhook: payment updates subscription status
- [ ] Mobile: app looks good on phone browser
- [ ] PWA: "Add to Home Screen" works
- [ ] Demo account ready: `demo@throughline.app` / `DemoPass123!`

---

## Next Steps After MVP

1. **Custom domain** — Connect your own domain via Vercel/Render settings
2. **SSL certificate** — Auto-provided by all platforms
3. **Monitoring** — Add Sentry for error tracking
4. **Analytics** — Add PostHog or Mixpanel (privacy-respecting)
5. **Native app** — Wrap PWA with Capacitor or build React Native
6. **Bank linking** — Integrate Plaid (requires compliance review)
7. **Wearables** — Apple Health / Google Fit APIs
