// API Configuration
const isDev = import.meta.env.DEV

export const API_BASE_URL = isDev 
  ? ''  // Uses Vite proxy in dev
  : 'https://habbits-app-2.onrender.com'

export const buildApiUrl = (path) => {
  if (path.startsWith('/api/')) {
    return `${API_BASE_URL}${path}`
  }
  return `${API_BASE_URL}/api/${path}`
}
