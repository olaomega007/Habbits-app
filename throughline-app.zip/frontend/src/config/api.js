// API Configuration
const isDev = import.meta.env.DEV

export const API_BASE_URL = isDev 
  ? ''  // Uses Vite proxy in dev
  : (import.meta.env.VITE_API_URL || 'https://your-api-url.com')

export const buildApiUrl = (path) => {
  if (path.startsWith('/api/')) {
    return `${API_BASE_URL}${path}`
  }
  return `${API_BASE_URL}/api/${path}`
}
