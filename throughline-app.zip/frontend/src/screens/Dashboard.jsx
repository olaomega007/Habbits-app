import React, { useState, useEffect, useContext } from 'react'
import { Link } from 'react-router-dom'
import { AuthContext } from '../App'
import { Lightbulb, TrendingUp, Calendar, ChevronRight, Sparkles, AlertCircle } from 'lucide-react'
import { format } from 'date-fns'

export default function Dashboard() {
  const { user, supabase } = useContext(AuthContext)
  const [stats, setStats] = useState(null)
  const [todayLogged, setTodayLogged] = useState(false)
  const [loading, setLoading] = useState(true)

  useEffect(() => {
    fetchDashboard()
    checkTodayLogs()
  }, [])

  const fetchDashboard = async () => {
    try {
      const token = (await supabase.auth.getSession()).data.session?.access_token
      const res = await fetch('/api/dashboard', {
        headers: { Authorization: `Bearer ${token}` }
      })
      if (res.ok) {
        const data = await res.json()
        setStats(data)
      }
    } catch (err) {
      console.error(err)
    } finally {
      setLoading(false)
    }
  }

  const checkTodayLogs = async () => {
    const today = format(new Date(), 'yyyy-MM-dd')
    const token = (await supabase.auth.getSession()).data.session?.access_token
    try {
      const res = await fetch(`/api/logs?start_date=${today}&end_date=${today}`, {
        headers: { Authorization: `Bearer ${token}` }
      })
      if (res.ok) {
        const data = await res.json()
        setTodayLogged(data.logs.length > 0)
      }
    } catch (err) {
      console.error(err)
    }
  }

  if (loading) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <div className="text-teal-400 animate-pulse">Loading your patterns...</div>
      </div>
    )
  }

  return (
    <div className="px-5 pt-6 pb-8 max-w-lg mx-auto">
      {/* Header */}
      <div className="mb-6">
        <h1 className="text-2xl font-bold text-white">Good {getGreeting()}</h1>
        <p className="text-slate-400 text-sm mt-1">
          {stats?.days_with_data > 0 
            ? `${stats.days_with_data} days of data — patterns are emerging.`
            : 'Start logging to discover your patterns.'}
        </p>
      </div>

      {/* Quick Log CTA */}
      {!todayLogged && (
        <Link
          to="/log"
          className="block mb-6 p-4 rounded-2xl bg-gradient-to-r from-teal-500/20 to-teal-600/10 border border-teal-500/30 card-hover"
        >
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-3">
              <div className="w-10 h-10 rounded-full bg-teal-500/20 flex items-center justify-center">
                <Calendar size={20} className="text-teal-400" />
              </div>
              <div>
                <p className="font-semibold text-teal-300">Log today</p>
                <p className="text-xs text-teal-400/70">Takes 10 seconds</p>
              </div>
            </div>
            <ChevronRight size={20} className="text-teal-400" />
          </div>
        </Link>
      )}

      {/* Stats Grid */}
      <div className="grid grid-cols-2 gap-3 mb-6">
        <div className="p-4 rounded-2xl glass card-hover">
          <p className="text-slate-400 text-xs font-medium uppercase tracking-wider">Total Logs</p>
          <p className="text-2xl font-bold text-white mt-1">{stats?.total_logs || 0}</p>
        </div>
        <div className="p-4 rounded-2xl glass card-hover">
          <p className="text-slate-400 text-xs font-medium uppercase tracking-wider">Days Tracked</p>
          <p className="text-2xl font-bold text-white mt-1">{stats?.days_with_data || 0}</p>
        </div>
      </div>

      {/* Latest Insight */}
      {stats?.latest_insight ? (
        <div className="mb-6 p-5 rounded-2xl glass border-l-4 border-teal-400 card-hover">
          <div className="flex items-start gap-3">
            <Lightbulb size={22} className="text-teal-400 mt-0.5 shrink-0" />
            <div>
              <p className="text-sm font-semibold text-teal-300 mb-1">Latest Insight</p>
              <p className="text-sm text-slate-300 leading-relaxed">{stats.latest_insight.insight_text}</p>
              <div className="flex items-center gap-2 mt-3">
                <span className={`text-[10px] px-2 py-0.5 rounded-full font-medium uppercase ${
                  stats.latest_insight.confidence_level === 'high' ? 'bg-teal-500/20 text-teal-300' :
                  stats.latest_insight.confidence_level === 'medium' ? 'bg-amber-500/20 text-amber-300' :
                  'bg-slate-500/20 text-slate-300'
                }`}>
                  {stats.latest_insight.confidence_level} confidence
                </span>
                {stats.unread_insights > 0 && (
                  <span className="text-[10px] px-2 py-0.5 rounded-full bg-rose-500/20 text-rose-300 font-medium">
                    {stats.unread_insights} new
                  </span>
                )}
              </div>
            </div>
          </div>
        </div>
      ) : (
        <div className="mb-6 p-5 rounded-2xl glass border border-slate-700/50">
          <div className="flex items-start gap-3">
            <AlertCircle size={22} className="text-amber-400 mt-0.5 shrink-0" />
            <div>
              <p className="text-sm font-semibold text-amber-300 mb-1">Still Learning</p>
              <p className="text-sm text-slate-400 leading-relaxed">
                Log at least 14 days of data across two domains (e.g., sleep + mood) 
                and we'll surface your first honest insight.
              </p>
            </div>
          </div>
        </div>
      )}

      {/* Recent Averages */}
      {stats?.recent_averages && stats.recent_averages.length > 0 && (
        <div className="mb-6">
          <h2 className="text-sm font-semibold text-slate-300 mb-3 flex items-center gap-2">
            <TrendingUp size={16} className="text-teal-400" />
            This Week (7-day avg)
          </h2>
          <div className="space-y-2">
            {stats.recent_averages.map(avg => (
              <div key={avg.metric_type} className="flex items-center justify-between p-3 rounded-xl bg-slate-800/50">
                <span className="text-sm text-slate-300 capitalize">{formatMetricName(avg.metric_type)}</span>
                <span className="text-sm font-semibold text-white">
                  {parseFloat(avg.avg_value).toFixed(1)}
                  <span className="text-slate-500 text-xs ml-1">({avg.count} days)</span>
                </span>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* Navigation Cards */}
      <div className="space-y-3">
        <Link to="/insights" className="flex items-center justify-between p-4 rounded-2xl glass card-hover">
          <div className="flex items-center gap-3">
            <Sparkles size={20} className="text-amber-400" />
            <span className="font-medium text-slate-200">All Insights</span>
          </div>
          <ChevronRight size={18} className="text-slate-500" />
        </Link>
        <Link to="/trends" className="flex items-center justify-between p-4 rounded-2xl glass card-hover">
          <div className="flex items-center gap-3">
            <TrendingUp size={20} className="text-teal-400" />
            <span className="font-medium text-slate-200">Trends & Charts</span>
          </div>
          <ChevronRight size={18} className="text-slate-500" />
        </Link>
      </div>
    </div>
  )
}

function getGreeting() {
  const hour = new Date().getHours()
  if (hour < 12) return 'morning'
  if (hour < 17) return 'afternoon'
  return 'evening'
}

function formatMetricName(type) {
  const map = {
    'spend_total': 'Daily Spending',
    'income': 'Income',
    'sleep_hours': 'Sleep Hours',
    'mood_rating': 'Mood Rating',
    'social_satisfaction': 'Relationship Satisfaction',
    'contact_frequency': 'Social Contact'
  }
  return map[type] || type.replace(/_/g, ' ')
}