import React, { useState, useContext } from 'react'
import { useNavigate } from 'react-router-dom'
import { AuthContext } from '../App'
import { format } from 'date-fns'
import { Check, Moon, Smile, DollarSign, Heart, Users, X } from 'lucide-react'

const METRICS = [
  {
    domain: 'mood_sleep',
    type: 'mood_rating',
    label: 'Mood',
    icon: Smile,
    min: 1, max: 5, step: 1,
    labels: ['1 - Low', '2', '3 - Okay', '4', '5 - Great'],
    color: 'teal'
  },
  {
    domain: 'mood_sleep',
    type: 'sleep_hours',
    label: 'Sleep',
    icon: Moon,
    min: 0, max: 12, step: 0.5,
    suffix: 'hrs',
    color: 'indigo'
  },
  {
    domain: 'finance',
    type: 'spend_total',
    label: 'Spending',
    icon: DollarSign,
    inputType: 'number',
    prefix: '$',
    color: 'rose'
  },
  {
    domain: 'finance',
    type: 'income',
    label: 'Income',
    icon: DollarSign,
    inputType: 'number',
    prefix: '$',
    color: 'emerald'
  },
  {
    domain: 'relationships',
    type: 'social_satisfaction',
    label: 'Relationship Satisfaction',
    icon: Heart,
    min: 1, max: 5, step: 1,
    labels: ['1 - Low', '2', '3 - Okay', '4', '5 - High'],
    color: 'rose'
  },
  {
    domain: 'relationships',
    type: 'contact_frequency',
    label: 'Social Contacts',
    icon: Users,
    min: 0, max: 10, step: 1,
    suffix: 'people',
    color: 'amber'
  }
]

export default function LogEntry() {
  const { supabase } = useContext(AuthContext)
  const navigate = useNavigate()
  const [date, setDate] = useState(format(new Date(), 'yyyy-MM-dd'))
  const [values, setValues] = useState({})
  const [notes, setNotes] = useState({})
  const [saving, setSaving] = useState(false)
  const [saved, setSaved] = useState(false)

  const handleValueChange = (metricType, value) => {
    setValues(prev => ({ ...prev, [metricType]: value }))
  }

  const handleNoteChange = (metricType, note) => {
    setNotes(prev => ({ ...prev, [metricType]: note }))
  }

  const handleSave = async () => {
    setSaving(true)
    const token = (await supabase.auth.getSession()).data.session?.access_token

    const entries = Object.entries(values).filter(([_, v]) => v !== '' && v !== undefined)

    if (entries.length === 0) {
      setSaving(false)
      return
    }

    try {
      for (const [metricType, value] of entries) {
        const metric = METRICS.find(m => m.type === metricType)
        await fetch('/api/logs', {
          method: 'POST',
          headers: {
            'Content-Type': 'application/json',
            Authorization: `Bearer ${token}`
          },
          body: JSON.stringify({
            log_date: date,
            domain: metric.domain,
            metric_type: metricType,
            value: parseFloat(value),
            note: notes[metricType] || null
          })
        })
      }
      setSaved(true)
      setTimeout(() => navigate('/'), 800)
    } catch (err) {
      console.error('Save error:', err)
    } finally {
      setSaving(false)
    }
  }

  if (saved) {
    return (
      <div className="min-h-screen flex items-center justify-center px-6">
        <div className="text-center">
          <div className="w-16 h-16 rounded-full bg-teal-500/20 flex items-center justify-center mx-auto mb-4">
            <Check size={32} className="text-teal-400" />
          </div>
          <h2 className="text-xl font-bold text-white mb-2">Logged!</h2>
          <p className="text-slate-400 text-sm">Your patterns are building.</p>
        </div>
      </div>
    )
  }

  return (
    <div className="px-5 pt-6 pb-8 max-w-lg mx-auto">
      <div className="flex items-center justify-between mb-6">
        <h1 className="text-2xl font-bold text-white">Daily Log</h1>
        <button onClick={() => navigate('/')} className="p-2 rounded-full hover:bg-slate-800">
          <X size={20} className="text-slate-400" />
        </button>
      </div>

      <div className="mb-6">
        <label className="block text-sm font-medium text-slate-300 mb-2">Date</label>
        <input
          type="date"
          value={date}
          onChange={e => setDate(e.target.value)}
          className="w-full px-4 py-3 rounded-xl text-sm"
        />
      </div>

      <div className="space-y-6">
        {METRICS.map(metric => (
          <MetricInput
            key={metric.type}
            metric={metric}
            value={values[metric.type]}
            note={notes[metric.type]}
            onValueChange={handleValueChange}
            onNoteChange={handleNoteChange}
          />
        ))}
      </div>

      <button
        onClick={handleSave}
        disabled={saving || Object.keys(values).length === 0}
        className="w-full mt-8 py-4 bg-teal-500 hover:bg-teal-400 disabled:bg-slate-700 disabled:text-slate-500 text-slate-900 font-bold rounded-xl transition-colors text-lg"
      >
        {saving ? 'Saving...' : 'Save Entry'}
      </button>

      <p className="text-center mt-4 text-xs text-slate-500">
        Fill only what you want. Optional fields are still valuable.
      </p>
    </div>
  )
}

function MetricInput({ metric, value, note, onValueChange, onNoteChange }) {
  const [showNote, setShowNote] = useState(false)
  const Icon = metric.icon
  const colorClass = {
    teal: 'text-teal-400 bg-teal-500/10 border-teal-500/30',
    indigo: 'text-indigo-400 bg-indigo-500/10 border-indigo-500/30',
    rose: 'text-rose-400 bg-rose-500/10 border-rose-500/30',
    emerald: 'text-emerald-400 bg-emerald-500/10 border-emerald-500/30',
    amber: 'text-amber-400 bg-amber-500/10 border-amber-500/30'
  }[metric.color]

  return (
    <div className="p-4 rounded-2xl glass">
      <div className="flex items-center gap-3 mb-3">
        <div className={`w-9 h-9 rounded-lg flex items-center justify-center ${colorClass}`}>
          <Icon size={18} />
        </div>
        <div className="flex-1">
          <p className="font-semibold text-slate-200">{metric.label}</p>
          {value !== undefined && value !== '' && (
            <p className="text-xs text-teal-400 font-medium">
              {metric.prefix || ''}{value}{metric.suffix || ''}
            </p>
          )}
        </div>
        <button
          onClick={() => setShowNote(!showNote)}
          className="text-xs text-slate-500 hover:text-slate-300 underline"
        >
          {showNote ? 'Hide note' : 'Add note'}
        </button>
      </div>

      {metric.inputType === 'number' ? (
        <input
          type="number"
          value={value || ''}
          onChange={e => onValueChange(metric.type, e.target.value)}
          placeholder={`Enter ${metric.label.toLowerCase()}...`}
          className="w-full px-4 py-3 rounded-xl text-sm"
        />
      ) : (
        <div className="flex gap-2">
          {Array.from({ length: Math.floor((metric.max - metric.min) / metric.step) + 1 }, (_, i) => {
            const val = metric.min + i * metric.step
            const isSelected = parseFloat(value) === val
            return (
              <button
                key={val}
                onClick={() => onValueChange(metric.type, val)}
                className={`flex-1 py-3 rounded-xl text-sm font-semibold transition-all metric-btn ${
                  isSelected
                    ? 'bg-teal-500 text-slate-900 shadow-lg shadow-teal-500/20'
                    : 'bg-slate-800 text-slate-400 hover:bg-slate-700'
                }`}
              >
                {val}
              </button>
            )
          })}
        </div>
      )}

      {metric.labels && (
        <div className="flex justify-between mt-2 px-1">
          {metric.labels.map((label, i) => (
            <span key={i} className="text-[10px] text-slate-500">{label}</span>
          ))}
        </div>
      )}

      {showNote && (
        <textarea
          value={note || ''}
          onChange={e => onNoteChange(metric.type, e.target.value)}
          placeholder={`Any notes about ${metric.label.toLowerCase()} today?`}
          className="w-full mt-3 px-4 py-3 rounded-xl text-sm resize-none h-20"
        />
      )}
    </div>
  )
}