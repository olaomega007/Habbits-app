import React, { useState, useEffect, useContext } from 'react'
import { AuthContext } from '../App'
import { LogOut, Shield, Download, Trash2, CreditCard, Crown, AlertTriangle } from 'lucide-react'

export default function Settings() {
  const { user, supabase, setUser } = useContext(AuthContext)
  const [subStatus, setSubStatus] = useState(null)
  const [showDeleteConfirm, setShowDeleteConfirm] = useState(false)

  useEffect(() => {
    fetchSubStatus()
  }, [])

  const fetchSubStatus = async () => {
    const token = (await supabase.auth.getSession()).data.session?.access_token
    try {
      const res = await fetch('/api/subscription/status', {
        headers: { Authorization: `Bearer ${token}` }
      })
      if (res.ok) {
        const data = await res.json()
        setSubStatus(data)
      }
    } catch (err) {
      console.error(err)
    }
  }

  const handleLogout = async () => {
    await supabase.auth.signOut()
    setUser(null)
  }

  const handleCheckout = async () => {
    const token = (await supabase.auth.getSession()).data.session?.access_token
    const res = await fetch('/api/subscription/checkout', {
      method: 'POST',
      headers: { 
        'Content-Type': 'application/json',
        Authorization: `Bearer ${token}` 
      }
    })
    const data = await res.json()
    if (data.url) window.location.href = data.url
  }

  const handleExport = async () => {
    const token = (await supabase.auth.getSession()).data.session?.access_token
    try {
      const res = await fetch('/api/logs', {
        headers: { Authorization: `Bearer ${token}` }
      })
      if (res.ok) {
        const data = await res.json()
        const blob = new Blob([JSON.stringify(data.logs, null, 2)], { type: 'application/json' })
        const url = URL.createObjectURL(blob)
        const a = document.createElement('a')
        a.href = url
        a.download = `throughline-data-${new Date().toISOString().split('T')[0]}.json`
        a.click()
        URL.revokeObjectURL(url)
      }
    } catch (err) {
      console.error('Export error:', err)
    }
  }

  const handleDeleteAll = async () => {
    const token = (await supabase.auth.getSession()).data.session?.access_token
    try {
      await fetch('/api/logs', { method: 'DELETE', headers: { Authorization: `Bearer ${token}` } })
      setShowDeleteConfirm(false)
      alert('All data deleted. Refresh to see changes.')
    } catch (err) {
      console.error('Delete error:', err)
    }
  }

  const isTrial = subStatus?.subscription_status === 'trial'
  const isActive = subStatus?.subscription_status === 'active'

  return (
    <div className="px-5 pt-6 pb-8 max-w-lg mx-auto">
      <h1 className="text-2xl font-bold text-white mb-6">Settings</h1>

      {/* User Info */}
      <div className="p-4 rounded-2xl glass mb-6">
        <p className="text-sm text-slate-400">Signed in as</p>
        <p className="text-white font-medium">{user?.email}</p>
      </div>

      {/* Subscription Card */}
      <div className="p-5 rounded-2xl glass mb-6 border border-teal-500/20">
        <div className="flex items-center gap-3 mb-3">
          <Crown size={22} className="text-teal-400" />
          <h2 className="font-semibold text-slate-200">Subscription</h2>
        </div>

        {isTrial && (
          <>
            <p className="text-sm text-slate-400 mb-3">
              Trial ends {subStatus?.trial_ends_at ? new Date(subStatus.trial_ends_at).toLocaleDateString() : 'soon'}
            </p>
            <button
              onClick={handleCheckout}
              className="w-full py-3 bg-teal-500 hover:bg-teal-400 text-slate-900 font-semibold rounded-xl transition-colors"
            >
              Upgrade to Pro — $4.99/mo
            </button>
          </>
        )}

        {isActive && (
          <div className="flex items-center gap-2 text-emerald-400">
            <Shield size={18} />
            <span className="text-sm font-medium">Active subscription</span>
          </div>
        )}

        {!isTrial && !isActive && (
          <p className="text-sm text-slate-400">Loading subscription status...</p>
        )}
      </div>

      {/* Data Controls */}
      <div className="space-y-3 mb-6">
        <button 
          onClick={handleExport}
          className="w-full flex items-center justify-between p-4 rounded-2xl glass card-hover text-left"
        >
          <div className="flex items-center gap-3">
            <Download size={20} className="text-teal-400" />
            <div>
              <span className="text-slate-200 font-medium block">Export My Data</span>
              <span className="text-xs text-slate-500">Download as JSON</span>
            </div>
          </div>
        </button>

        {!showDeleteConfirm ? (
          <button 
            onClick={() => setShowDeleteConfirm(true)}
            className="w-full flex items-center justify-between p-4 rounded-2xl glass card-hover text-left"
          >
            <div className="flex items-center gap-3">
              <Trash2 size={20} className="text-rose-400" />
              <span className="text-rose-300 font-medium">Delete All Data</span>
            </div>
          </button>
        ) : (
          <div className="p-4 rounded-2xl bg-rose-500/10 border border-rose-500/30">
            <div className="flex items-start gap-3 mb-3">
              <AlertTriangle size={18} className="text-rose-400 mt-0.5 shrink-0" />
              <p className="text-sm text-rose-300">
                This permanently deletes all your logs and insights. This cannot be undone.
              </p>
            </div>
            <div className="flex gap-3">
              <button 
                onClick={handleDeleteAll}
                className="flex-1 py-2 bg-rose-500 hover:bg-rose-400 text-white font-medium rounded-xl text-sm"
              >
                Yes, delete everything
              </button>
              <button 
                onClick={() => setShowDeleteConfirm(false)}
                className="flex-1 py-2 bg-slate-700 hover:bg-slate-600 text-slate-200 font-medium rounded-xl text-sm"
              >
                Cancel
              </button>
            </div>
          </div>
        )}
      </div>

      {/* Privacy Note */}
      <div className="p-4 rounded-2xl bg-slate-800/50 border border-slate-700/50 mb-6">
        <div className="flex items-start gap-3">
          <Shield size={18} className="text-teal-400 mt-0.5 shrink-0" />
          <div>
            <p className="text-sm font-medium text-slate-300 mb-1">Your data, your rules</p>
            <p className="text-xs text-slate-400 leading-relaxed">
              Encrypted at rest. You own it completely. We use it only to calculate 
              patterns in your own history — never for advertising, never sold, never 
              used to predict your future.
            </p>
          </div>
        </div>
      </div>

      {/* Logout */}
      <button
        onClick={handleLogout}
        className="w-full py-3 border border-slate-600 text-slate-300 font-medium rounded-xl hover:bg-slate-800 transition-colors flex items-center justify-center gap-2"
      >
        <LogOut size={18} />
        Sign Out
      </button>
    </div>
  )
}