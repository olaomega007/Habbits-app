import React, { useState, useEffect, useContext } from 'react'
import { AuthContext } from '../App'
import { LineChart, Line, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, BarChart, Bar } from 'recharts'
import { format, parseISO, subDays } from 'date-fns'
import { TrendingUp, Calendar } from 'lucide-react'

const TIME_RANGES = [
  { label: '7 Days', days: 7 },
  { label: '14 Days', days: 14 },
  { label: '30 Days', days: 30 },
  { label: '90 Days', days: 90 }
]

const METRIC_OPTIONS = [
  { value: 'mood_rating', label: 'Mood', color: '#2dd4bf' },
  { value: 'sleep_hours', label: 'Sleep', color: '#818cf8' },
  { value: 'spend_total', label: 'Spending', color: '#fb7185' },
  { value: 'income', label: 'Income', color: '#34d399' },
  { value: 'social_satisfaction', label: 'Relationships', color: '#fbbf24' },
  { value: 'contact_frequency', label: 'Social Contact', color: '#a78bfa' }
]

export default function Trends() {
  const { supabase } = useContext(AuthContext)
  const [logs, setLogs] = useState([])
  const [selectedRange, setSelectedRange] = useState(14)
  const [selectedMetrics, setSelectedMetrics] = useState(['mood_rating', 'sleep_hours'])
  const [loading, setLoading] = useState(true)

  useEffect(() => {
    fetchLogs()
  }, [selectedRange])

  const fetchLogs = async () => {
    setLoading(true)
    const endDate = format(new Date(), 'yyyy-MM-dd')
    const startDate = format(subDays(new Date(), selectedRange), 'yyyy-MM-dd')

    try {
      const token = (await supabase.auth.getSession()).data.session?.access_token
      const res = await fetch(`/api/logs?start_date=${startDate}&end_date=${endDate}`, {
        headers: { Authorization: `Bearer ${token}` }
      })
      if (res.ok) {
        const data = await res.json()
        setLogs(data.logs)
      }
    } catch (err) {
      console.error(err)
    } finally {
      setLoading(false)
    }
  }

  const toggleMetric = (metric) => {
    setSelectedMetrics(prev => 
      prev.includes(metric) 
        ? prev.filter(m => m !== metric)
        : [...prev, metric]
    )
  }

  // Transform logs into chart data
  const chartData = React.useMemo(() => {
    const dateMap = {}

    // Initialize all dates in range
    const end = new Date()
    const start = subDays(end, selectedRange)
    const days = []
    for (let d = new Date(start); d <= end; d.setDate(d.getDate() + 1)) {
      const dateStr = format(d, 'yyyy-MM-dd')
      days.push(dateStr)
      dateMap[dateStr] = { date: dateStr, displayDate: format(d, 'MMM d') }
    }

    // Fill in log values
    logs.forEach(log => {
      if (dateMap[log.log_date]) {
        dateMap[log.log_date][log.metric_type] = parseFloat(log.value)
      }
    })

    return Object.values(dateMap)
  }, [logs, selectedRange])

  return (
    <div className="px-5 pt-6 pb-8 max-w-lg mx-auto">
      <div className="mb-6">
        <h1 className="text-2xl font-bold text-white">Trends</h1>
        <p className="text-slate-400 text-sm mt-1">Your data, visualized.</p>
      </div>

      {/* Time Range Selector */}
      <div className="flex gap-2 mb-6 overflow-x-auto hide-scrollbar">
        {TIME_RANGES.map(range => (
          <button
            key={range.days}
            onClick={() => setSelectedRange(range.days)}
            className={`px-4 py-2 rounded-xl text-sm font-medium whitespace-nowrap transition-colors ${
              selectedRange === range.days
                ? 'bg-teal-500 text-slate-900'
                : 'bg-slate-800 text-slate-400 hover:bg-slate-700'
            }`}
          >
            {range.label}
          </button>
        ))}
      </div>

      {/* Metric Toggles */}
      <div className="flex flex-wrap gap-2 mb-6">
        {METRIC_OPTIONS.map(metric => {
          const isSelected = selectedMetrics.includes(metric.value)
          return (
            <button
              key={metric.value}
              onClick={() => toggleMetric(metric.value)}
              className={`px-3 py-1.5 rounded-full text-xs font-medium transition-all ${
                isSelected
                  ? 'text-slate-900'
                  : 'bg-slate-800 text-slate-400 hover:bg-slate-700'
              }`}
              style={isSelected ? { backgroundColor: metric.color } : {}}
            >
              {metric.label}
            </button>
          )
        })}
      </div>

      {loading ? (
        <div className="h-64 flex items-center justify-center">
          <div className="text-teal-400 animate-pulse">Loading charts...</div>
        </div>
      ) : chartData.length === 0 || logs.length === 0 ? (
        <div className="text-center py-16">
          <TrendingUp size={48} className="text-slate-600 mx-auto mb-4" />
          <p className="text-slate-400 font-medium mb-2">No data yet</p>
          <p className="text-slate-500 text-sm">Start logging to see your trends.</p>
        </div>
      ) : (
        <div className="space-y-6">
          {/* Line Chart */}
          <div className="p-4 rounded-2xl glass">
            <h3 className="text-sm font-semibold text-slate-300 mb-4">Overview</h3>
            <div className="h-64">
              <ResponsiveContainer width="100%" height="100%">
                <LineChart data={chartData}>
                  <CartesianGrid strokeDasharray="3 3" stroke="#334155" />
                  <XAxis 
                    dataKey="displayDate" 
                    stroke="#64748b" 
                    fontSize={10}
                    tickLine={false}
                  />
                  <YAxis stroke="#64748b" fontSize={10} tickLine={false} />
                  <Tooltip 
                    contentStyle={{ 
                      backgroundColor: '#1e293b', 
                      border: '1px solid #334155',
                      borderRadius: '12px',
                      fontSize: '12px'
                    }}
                  />
                  {selectedMetrics.map(metric => {
                    const metricConfig = METRIC_OPTIONS.find(m => m.value === metric)
                    return (
                      <Line
                        key={metric}
                        type="monotone"
                        dataKey={metric}
                        stroke={metricConfig?.color || '#fff'}
                        strokeWidth={2}
                        dot={false}
                        connectNulls
                      />
                    )
                  })}
                </LineChart>
              </ResponsiveContainer>
            </div>
          </div>

          {/* Individual Metric Cards */}
          {selectedMetrics.map(metric => {
            const metricConfig = METRIC_OPTIONS.find(m => m.value === metric)
            const values = chartData.map(d => d[metric]).filter(v => v !== undefined)
            const avg = values.length > 0 ? (values.reduce((a, b) => a + b, 0) / values.length).toFixed(1) : '-'
            const min = values.length > 0 ? Math.min(...values).toFixed(1) : '-'
            const max = values.length > 0 ? Math.max(...values).toFixed(1) : '-'

            return (
              <div key={metric} className="p-4 rounded-2xl glass">
                <div className="flex items-center justify-between mb-3">
                  <h3 className="text-sm font-semibold" style={{ color: metricConfig?.color }}>
                    {metricConfig?.label}
                  </h3>
                  <span className="text-xs text-slate-500">{values.length} data points</span>
                </div>
                <div className="grid grid-cols-3 gap-3">
                  <div className="text-center p-2 rounded-xl bg-slate-800/50">
                    <p className="text-xs text-slate-500">Avg</p>
                    <p className="text-lg font-bold text-white">{avg}</p>
                  </div>
                  <div className="text-center p-2 rounded-xl bg-slate-800/50">
                    <p className="text-xs text-slate-500">Min</p>
                    <p className="text-lg font-bold text-white">{min}</p>
                  </div>
                  <div className="text-center p-2 rounded-xl bg-slate-800/50">
                    <p className="text-xs text-slate-500">Max</p>
                    <p className="text-lg font-bold text-white">{max}</p>
                  </div>
                </div>
              </div>
            )
          })}
        </div>
      )}
    </div>
  )
}