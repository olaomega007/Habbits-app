import React, { useState, useEffect, useContext } from 'react'
import { AuthContext } from '../App'
import { Lightbulb, CheckCircle, AlertTriangle, Info, ChevronRight } from 'lucide-react'

export default function Insights() {
  const { supabase } = useContext(AuthContext)
  const [insights, setInsights] = useState([])
  const [loading, setLoading] = useState(true)

  useEffect(() => {
    fetchInsights()
  }, [])

  const fetchInsights = async () => {
    try {
      const token = (await supabase.auth.getSession()).data.session?.access_token
      const res = await fetch('/api/insights', {
        headers: { Authorization: `Bearer ${token}` }
      })
      if (res.ok) {
        const data = await res.json()
        setInsights(data.insights)
      }
    } catch (err) {
      console.error(err)
    } finally {
      setLoading(false)
    }
  }

  const markAsRead = async (id) => {
    const token = (await supabase.auth.getSession()).data.session?.access_token
    try {
      await fetch(`/api/insights/${id}/read`, {
        method: 'PATCH',
        headers: { Authorization: `Bearer ${token}` }
      })
      setInsights(prev => prev.map(i => i.id === id ? { ...i, is_read: true } : i))
    } catch (err) {
      console.error(err)
    }
  }

  if (loading) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <div className="text-teal-400 animate-pulse">Analyzing your patterns...</div>
      </div>
    )
  }

  return (
    <div className="px-5 pt-6 pb-8 max-w-lg mx-auto">
      <div className="mb-6">
        <h1 className="text-2xl font-bold text-white">Insights</h1>
        <p className="text-slate-400 text-sm mt-1">
          Honest, data-grounded patterns from your own life.
        </p>
      </div>

      {/* Honesty Banner */}
      <div className="mb-6 p-4 rounded-2xl bg-amber-500/10 border border-amber-500/20 flex items-start gap-3">
        <Info size={18} className="text-amber-400 mt-0.5 shrink-0" />
        <p className="text-xs text-amber-300/80 leading-relaxed">
          These describe what your data shows — not predictions about your future. 
          Confidence levels reflect how much data we have, not certainty about causation.
        </p>
      </div>

      {insights.length === 0 ? (
        <div className="text-center py-16">
          <Lightbulb size={48} className="text-slate-600 mx-auto mb-4" />
          <p className="text-slate-400 font-medium mb-2">No insights yet</p>
          <p className="text-slate-500 text-sm max-w-xs mx-auto">
            Keep logging across at least two domains for 14 days. 
            We'll surface your first pattern automatically.
          </p>
        </div>
      ) : (
        <div className="space-y-4">
          {insights.map(insight => (
            <InsightCard key={insight.id} insight={insight} onMarkRead={markAsRead} />
          ))}
        </div>
      )}
    </div>
  )
}

function InsightCard({ insight, onMarkRead }) {
  const confidenceColors = {
    high: { bg: 'bg-teal-500/10', border: 'border-teal-500/30', text: 'text-teal-300', badge: 'bg-teal-500/20 text-teal-300' },
    medium: { bg: 'bg-amber-500/10', border: 'border-amber-500/30', text: 'text-amber-300', badge: 'bg-amber-500/20 text-amber-300' },
    low: { bg: 'bg-slate-500/10', border: 'border-slate-500/30', text: 'text-slate-300', badge: 'bg-slate-500/20 text-slate-300' }
  }
  const colors = confidenceColors[insight.confidence_level]

  return (
    <div className={`p-5 rounded-2xl ${colors.bg} border ${colors.border} card-hover relative`}>
      {!insight.is_read && (
        <div className="absolute top-4 right-4 w-2 h-2 rounded-full bg-teal-400" />
      )}

      <div className="flex items-start gap-3 mb-3">
        <Lightbulb size={20} className={colors.text + ' mt-0.5 shrink-0'} />
        <div className="flex-1">
          <p className="text-sm text-slate-200 leading-relaxed">{insight.insight_text}</p>
        </div>
      </div>

      <div className="flex items-center justify-between mt-4">
        <div className="flex items-center gap-2">
          <span className={`text-[10px] px-2 py-0.5 rounded-full font-medium uppercase ${colors.badge}`}>
            {insight.confidence_level} confidence
          </span>
          {insight.correlation_value && (
            <span className="text-[10px] text-slate-500">
              r = {parseFloat(insight.correlation_value).toFixed(2)}
            </span>
          )}
        </div>

        {!insight.is_read && (
          <button
            onClick={() => onMarkRead(insight.id)}
            className="flex items-center gap-1 text-xs text-teal-400 hover:text-teal-300 font-medium"
          >
            <CheckCircle size={14} />
            Mark read
          </button>
        )}
      </div>

      {insight.domains_involved && (
        <div className="flex gap-2 mt-3">
          {insight.domains_involved.map(domain => (
            <span key={domain} className="text-[10px] px-2 py-0.5 rounded-full bg-slate-700/50 text-slate-400 capitalize">
              {domain.replace('_', ' ')}
            </span>
          ))}
        </div>
      )}
    </div>
  )
}