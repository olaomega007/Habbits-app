import React, { useState, useEffect, createContext } from 'react'
import { Routes, Route, Navigate, useLocation } from 'react-router-dom'
import { createClient } from '@supabase/supabase-js'
import Dashboard from './screens/Dashboard'
import LogEntry from './screens/LogEntry'
import Insights from './screens/Insights'
import Trends from './screens/Trends'
import Settings from './screens/Settings'
import Login from './screens/Login'
import BottomNav from './components/BottomNav'

const supabaseUrl = import.meta.env.VITE_SUPABASE_URL || 'https://flmoqlkoqgvrxuzcnuqg.supabase.co'
const supabaseKey = import.meta.env.VITE_SUPABASE_ANON_KEY || 'sb_publishable_Os6B4OWTcoF_mhq9nl_Chw_jmlXwsBC'
export const supabase = createClient(supabaseUrl, supabaseKey)

export const AuthContext = createContext(null)

function App() {
  const [user, setUser] = useState(null)
  const [loading, setLoading] = useState(true)
  const location = useLocation()

  useEffect(() => {
    supabase.auth.getSession().then(({ data: { session } }) => {
      setUser(session?.user || null)
      setLoading(false)
    })

    const { data: { subscription } } = supabase.auth.onAuthStateChange((_event, session) => {
      setUser(session?.user || null)
    })

    return () => subscription.unsubscribe()
  }, [])

  if (loading) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-slate-950">
        <div className="text-teal-400 text-lg font-medium animate-pulse">Throughline</div>
      </div>
    )
  }

  const showNav = user && !location.pathname.includes('/login')

  return (
    <AuthContext.Provider value={{ user, setUser, supabase }}>
      <div className="min-h-screen bg-slate-950 text-slate-100 pb-20">
        <Routes>
          <Route path="/login" element={user ? <Navigate to="/" /> : <Login />} />
          <Route path="/" element={user ? <Dashboard /> : <Navigate to="/login" />} />
          <Route path="/log" element={user ? <LogEntry /> : <Navigate to="/login" />} />
          <Route path="/insights" element={user ? <Insights /> : <Navigate to="/login" />} />
          <Route path="/trends" element={user ? <Trends /> : <Navigate to="/login" />} />
          <Route path="/settings" element={user ? <Settings /> : <Navigate to="/login" />} />
        </Routes>
        {showNav && <BottomNav />}
      </div>
    </AuthContext.Provider>
  )
}

export default App