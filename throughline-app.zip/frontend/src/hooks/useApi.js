import { useContext, useCallback } from 'react'
import { AuthContext } from '../App'
import { buildApiUrl } from '../config/api'

export function useApi() {
  const { supabase } = useContext(AuthContext)

  const apiFetch = useCallback(async (endpoint, options = {}) => {
    const session = await supabase.auth.getSession()
    const token = session.data.session?.access_token

    const url = buildApiUrl(endpoint)

    const res = await fetch(url, {
      ...options,
      headers: {
        ...(options.headers || {}),
        'Content-Type': 'application/json',
        ...(token ? { Authorization: `Bearer ${token}` } : {})
      }
    })

    if (!res.ok) {
      const err = await res.json().catch(() => ({}))
      throw new Error(err.error || `HTTP ${res.status}`)
    }

    return res.json()
  }, [supabase])

  return { apiFetch }
}
