# Throughline — Cross-Domain Habit Insight App

> A cross-domain habit tracker that surfaces honest, data-grounded correlations across your own recorded history — not predictions of an unknowable future.

## Architecture

| Layer | Technology |
|-------|-----------|
| Frontend | React 18 + Vite + Tailwind CSS + Recharts |
| Backend | Node.js + Express |
| Database | PostgreSQL (Supabase) |
| Auth | Supabase Auth |
| Payments | Stripe (subscription model) |
| Hosting | PWA (web-first), native app later |

## Quick Start

### Prerequisites
- Node.js 18+
- PostgreSQL 14+ (or use Supabase hosted)
- Supabase account (free tier)
- Stripe account (test mode)

### 1. Backend Setup

```bash
cd backend
npm install

# Copy and fill env
cp .env.example .env
# Edit .env with your real keys

# Run database migrations (or use Supabase SQL Editor)
psql $DATABASE_URL < schema.sql

# Seed demo data (optional, for investor demo)
node seed.js

# Start server
npm run dev
```

### 2. Frontend Setup

```bash
cd frontend
npm install

# Copy and fill env
cp .env.example .env.local
# Edit .env.local with your Supabase keys

# Start dev server
npm run dev
```

### 3. Stripe Webhook (for local dev)

```bash
# Install Stripe CLI
stripe login
stripe listen --forward-to http://localhost:3001/api/webhooks/stripe
# Copy the webhook signing secret to .env
```

## Environment Variables

### Backend (.env)
```
SUPABASE_URL=https://flmoqlkoqgvrxuzcnuqg.supabase.co
SUPABASE_ANON_KEY=sb_publishable_Os6B4OWTcoF_mhq9nl_Chw_jmlXwsBC
SUPABASE_SERVICE_ROLE_KEY=sb_secret_rTNJql1Feo0hsqGtNdnqgw_-WlMJNiQ
DATABASE_URL=postgresql://...
JWT_SECRET=your_jwt_secret
STRIPE_SECRET_KEY=sk_test_51TvpnFR1LulYB9FPsBFaSEtOKiPq2WNWC3sXHKRxHEXJ23FnSO8nVSrEbBcQYOEYENQeFqFVyNppQM1L32ZBAFhK00PsHImZMD
STRIPE_WEBHOOK_SECRET=whsec_...
STRIPE_PRICE_ID=price_...
PORT=3001
```

### Frontend (.env.local)
```
VITE_SUPABASE_URL=https://flmoqlkoqgvrxuzcnuqg.supabase.co
VITE_SUPABASE_ANON_KEY=sb_publishable_Os6B4OWTcoF_mhq9nl_Chw_jmlXwsBC
VITE_STRIPE_PUBLISHABLE_KEY=pk_test_51TvpnFR1LulYB9FPGnaWDbOYsCyxGkpUuoxWUUGoFU0U03g4XwPtx7uB6Y5dZv9wVeNjfRMliQ1pPgsbP5JJySkN00oqfUmp1o
```

## API Endpoints

| Method | Endpoint | Description |
|--------|----------|-------------|
| POST | /api/logs | Create/update log entry |
| GET | /api/logs | Get logs (filter by date, domain, metric) |
| DELETE | /api/logs/:id | Delete a log |
| GET | /api/insights | Get all insights |
| PATCH | /api/insights/:id/read | Mark insight as read |
| GET | /api/dashboard | Dashboard summary stats |
| POST | /api/subscription/checkout | Create Stripe checkout |
| GET | /api/subscription/status | Get subscription status |
| POST | /api/webhooks/stripe | Stripe webhook handler |

## Core Correlation Engine

The engine uses **Pearson correlation** on aligned date pairs between metrics. Insights are only surfaced when:
- Minimum 14 days of paired data
- |correlation| >= 0.3
- Plain-language framing ("In your logged data...")
- Visible confidence level based on data volume

**Never predicts the future.** Only describes what the data shows.

## Project Structure

```
throughline-app/
├── backend/
│   ├── server.js          # Express app + correlation engine
│   ├── schema.sql         # Database schema
│   ├── seed.js            # Demo data generator
│   ├── package.json
│   └── .env.example
├── frontend/
│   ├── src/
│   │   ├── App.jsx        # Router + auth context
│   │   ├── main.jsx       # Entry point
│   │   ├── screens/       # Dashboard, LogEntry, Insights, Trends, Settings
│   │   └── components/    # BottomNav, etc.
│   ├── index.html
│   ├── vite.config.js
│   └── package.json
```

## Deployment

### Backend
- Railway, Render, or Fly.io
- Set all env vars in platform dashboard
- Run `schema.sql` on production database

### Frontend
- Vercel or Netlify
- Build command: `npm run build`
- Output directory: `dist`
- Set `VITE_*` env vars in platform dashboard

### PWA
- App is configured as PWA via Vite plugin
- Users can "Add to Home Screen" on mobile
- Works offline after first load

## Security Checklist

- [x] Row Level Security (RLS) on all tables
- [x] JWT auth via Supabase
- [x] Encryption at rest (Supabase default)
- [x] Data export functionality
- [x] Data deletion functionality
- [x] Plain-language privacy policy
- [ ] App Store privacy disclosure (before native release)
- [ ] SOC 2 / GDPR compliance audit (before scaling)

## License

Proprietary — Throughline Inc.
