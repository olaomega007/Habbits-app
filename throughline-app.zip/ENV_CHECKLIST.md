# Throughline — Environment Variables Checklist

## Backend (.env)

| Variable | Value | Status |
|----------|-------|--------|
| SUPABASE_URL | https://flmoqlkoqgvrxuzcnuqg.supabase.co | ✅ Set |
| SUPABASE_ANON_KEY | sb_publishable_Os6B4OWTcoF_mhq9nl_Chw_jmlXwsBC | ✅ Set |
| SUPABASE_SERVICE_ROLE_KEY | sb_secret_rTNJql1Feo0hsqGtNdnqgw_-WlMJNiQ | ✅ Set |
| DATABASE_URL | postgresql://postgres:[PASSWORD]@db.flmoqlkoqgvrxuzcnuqg.supabase.co:5432/postgres | ⚠️ NEEDS PASSWORD |
| JWT_SECRET | [From Supabase Project Settings > API > JWT Settings] | ⚠️ NEEDS VALUE |
| STRIPE_SECRET_KEY | sk_test_51TvpnFR1LulYB9FPsBFaSEtOKiPq2WNWC3sXHKRxHEXJ23FnSO8nVSrEbBcQYOEYENQeFqFVyNppQM1L32ZBAFhK00PsHImZMD | ✅ Set |
| STRIPE_WEBHOOK_SECRET | whsec_... | ⚠️ NEEDS VALUE (after deploy) |
| STRIPE_PRICE_ID | price_1TvqEER1LulYB9FPHokKaEBh | ✅ Set |
| PORT | 3001 | ✅ Set |
| NODE_ENV | production | ✅ Set |

## Frontend (.env.local)

| Variable | Value | Status |
|----------|-------|--------|
| VITE_SUPABASE_URL | https://flmoqlkoqgvrxuzcnuqg.supabase.co | ✅ Set |
| VITE_SUPABASE_ANON_KEY | sb_publishable_Os6B4OWTcoF_mhq9nl_Chw_jmlXwsBC | ✅ Set |
| VITE_STRIPE_PUBLISHABLE_KEY | pk_test_51TvpnFR1LulYB9FPGnaWDbOYsCyxGkpUuoxWUUGoFU0U03g4XwPtx7uB6Y5dZv9wVeNjfRMliQ1pPgsbP5JJySkN00oqfUmp1o | ✅ Set |

## Actions Needed

1. [ ] Get Supabase database password (Project Settings > Database)
2. [ ] Get Supabase JWT secret (Project Settings > API)
3. [ ] Deploy backend to Render
4. [ ] Get webhook secret from Stripe Dashboard (after adding endpoint)
5. [ ] Deploy frontend to Vercel
6. [ ] Run schema.sql on production database
7. [ ] Run seed.js for demo data
